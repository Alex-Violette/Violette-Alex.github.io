function maFonction() {
	alert("J'avais prévenu que c'était un bouton inutile. Vous pouvez vous amuser avec autant que vous voulez. Il est votre meilleur ami. Et qu'avez vous pensé de mon site ?")
}